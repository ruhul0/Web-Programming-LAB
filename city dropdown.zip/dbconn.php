<?php
//Database credentials
$dbHost     = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName     = 'assign1';

//Connect and select the database
$dbhandle = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($dbhandle->connect_error) {
    die("Connection failed: " . $dbhandle->connect_error);
}
?>